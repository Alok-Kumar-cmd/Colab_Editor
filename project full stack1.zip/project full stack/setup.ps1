# PowerShell Setup Script for Real-Time Analytics Dashboard
# Run this script to set up the project

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Real-Time Analytics Dashboard Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check Node.js
Write-Host "Checking Node.js installation..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version
    Write-Host "✓ Node.js found: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Node.js not found!" -ForegroundColor Red
    Write-Host "Please install Node.js from https://nodejs.org/" -ForegroundColor Red
    exit 1
}

# Check npm
Write-Host "Checking npm installation..." -ForegroundColor Yellow
try {
    $npmVersion = npm --version
    Write-Host "✓ npm found: $npmVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ npm not found!" -ForegroundColor Red
    exit 1
}

# Check Docker (optional)
Write-Host "Checking Docker installation..." -ForegroundColor Yellow
try {
    $dockerVersion = docker --version
    Write-Host "✓ Docker found: $dockerVersion" -ForegroundColor Green
    $dockerAvailable = $true
} catch {
    Write-Host "⚠ Docker not found (optional, but recommended)" -ForegroundColor Yellow
    Write-Host "  You can install Docker Desktop from https://www.docker.com/products/docker-desktop/" -ForegroundColor Yellow
    $dockerAvailable = $false
}

Write-Host ""

# Create .env file
Write-Host "Creating backend/.env file..." -ForegroundColor Yellow
$envPath = "backend\.env"
if (Test-Path $envPath) {
    Write-Host "✓ .env file already exists" -ForegroundColor Green
} else {
    $envContent = @"
NODE_ENV=development
PORT=3001
MONGODB_URI=mongodb://admin:admin123@localhost:27017/analytics?authSource=admin
JWT_SECRET=your-super-secret-jwt-key-change-in-production
JWT_EXPIRES_IN=24h
CORS_ORIGIN=http://localhost:3000
WS_MAX_MESSAGE_SIZE=100000
WS_RATE_LIMIT_WINDOW=60000
WS_RATE_LIMIT_MAX=1000
REST_RATE_LIMIT_WINDOW=60000
REST_RATE_LIMIT_MAX=100
LOG_LEVEL=info
"@
    $envContent | Out-File -FilePath $envPath -Encoding utf8
    Write-Host "✓ Created backend/.env file" -ForegroundColor Green
}

# Install dependencies
Write-Host ""
Write-Host "Installing dependencies..." -ForegroundColor Yellow
Write-Host "This may take a few minutes..." -ForegroundColor Yellow

# Root dependencies
if (Test-Path "package.json") {
    Write-Host "Installing root dependencies..." -ForegroundColor Cyan
    npm install
}

# Backend dependencies
if (Test-Path "backend\package.json") {
    Write-Host "Installing backend dependencies..." -ForegroundColor Cyan
    Set-Location backend
    npm install
    Set-Location ..
}

# Frontend dependencies
if (Test-Path "frontend\package.json") {
    Write-Host "Installing frontend dependencies..." -ForegroundColor Cyan
    Set-Location frontend
    npm install
    Set-Location ..
}

Write-Host "✓ Dependencies installed" -ForegroundColor Green

# Start MongoDB if Docker is available
if ($dockerAvailable) {
    Write-Host ""
    Write-Host "Starting MongoDB container..." -ForegroundColor Yellow
    try {
        docker-compose up -d
        Start-Sleep -Seconds 5
        Write-Host "✓ MongoDB container started" -ForegroundColor Green
    } catch {
        Write-Host "⚠ Failed to start MongoDB container" -ForegroundColor Yellow
        Write-Host "  You can start it manually with: docker-compose up -d" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Start development servers: npm run dev" -ForegroundColor White
Write-Host "2. Open http://localhost:3000 in your browser" -ForegroundColor White
Write-Host "3. (Optional) Seed database: npm run seed" -ForegroundColor White
Write-Host ""

