# Project Structure

## Directory Layout

```
.
├── backend/                 # Node.js backend
│   ├── src/
│   │   ├── server.js       # Main server entry point
│   │   ├── config/          # Configuration management
│   │   │   └── index.js
│   │   ├── models/          # Data models
│   │   │   └── Event.js
│   │   ├── routes/          # REST API routes
│   │   │   ├── events.js    # Event ingestion endpoints
│   │   │   ├── metrics.js   # Metrics endpoints
│   │   │   ├── health.js    # Health/readiness checks
│   │   │   └── auth.js       # Authentication endpoints
│   │   ├── middleware/       # Express middleware
│   │   │   ├── auth.js      # JWT authentication
│   │   │   └── validation.js # Input validation
│   │   ├── services/        # Business logic
│   │   │   └── eventService.js
│   │   ├── db/              # Database connection
│   │   │   └── connection.js
│   │   ├── websocket/       # WebSocket handlers
│   │   │   └── handler.js   # Socket.io event handlers
│   │   ├── aggregators/     # Rolling aggregates
│   │   │   └── rollingAggregator.js
│   │   ├── utils/           # Utilities
│   │   │   └── logger.js    # Winston logger
│   │   └── scripts/         # Utility scripts
│   │       ├── seed.js      # Database seeding
│   │       ├── loadGenerator.js # Load testing
│   │       └── createEnv.js
│   ├── package.json
│   └── .env.example
│
├── frontend/                # React frontend
│   ├── src/
│   │   ├── App.js           # Main app component
│   │   ├── components/      # React components
│   │   │   ├── Dashboard.js # Main dashboard
│   │   │   ├── Dashboard.css
│   │   │   ├── EventGenerator.js # Demo event generator
│   │   │   └── EventGenerator.css
│   │   ├── services/        # API clients
│   │   │   ├── websocket.js # WebSocket service
│   │   │   └── api.js       # REST API client
│   │   ├── index.js         # React entry point
│   │   └── index.css
│   ├── public/
│   │   └── index.html
│   └── package.json
│
├── docker-compose.yml        # MongoDB container
├── Makefile                 # Development commands
├── package.json             # Root package.json
├── README.md                # Main documentation
├── QUICKSTART.md            # Quick start guide
└── .gitignore
```

## Key Components

### Backend

**Server (`server.js`)**
- Express HTTP server
- Socket.io WebSocket server
- Shared aggregator instance
- Route registration
- Graceful shutdown

**WebSocket Handler (`websocket/handler.js`)**
- Client connection management
- Event ingestion via WebSocket
- Rate limiting per client
- Real-time metric broadcasting
- Reconnection handling

**Rolling Aggregator (`aggregators/rollingAggregator.js`)**
- Multi-window aggregation (1s, 5s, 60s)
- Event counting and unique user tracking
- Route popularity calculation
- Error rate computation
- Automatic cleanup of old windows
- MongoDB persistence

**Event Service (`services/eventService.js`)**
- Event ingestion with idempotency
- Batch processing
- Database queries
- Duplicate detection via eventId

**Routes**
- `/api/events` - Single/batch event ingestion
- `/api/metrics` - Current metrics
- `/api/health` - Health check
- `/api/ready` - Readiness check
- `/api/auth/demo` - Demo authentication

### Frontend

**Dashboard (`components/Dashboard.js`)**
- Real-time chart updates
- Multiple chart types (Line, Bar)
- Time range filtering
- Connection status indicator
- Error handling and recovery

**WebSocket Service (`services/websocket.js`)**
- Automatic reconnection with exponential backoff
- Event listener management
- Connection state tracking
- Error handling

**Event Generator (`components/EventGenerator.js`)**
- Demo event generation
- Configurable intervals
- WebSocket/REST fallback
- Statistics display

## Data Flow

1. **Event Ingestion**
   - Client sends event via WebSocket or REST
   - Validation middleware checks schema
   - Event service stores in MongoDB
   - Aggregator updates rolling windows
   - Event acknowledged to client

2. **Aggregation**
   - Aggregator maintains in-memory windows
   - Updates every 100ms
   - Persists to MongoDB every 5 seconds
   - Cleans up old windows periodically

3. **Broadcasting**
   - Aggregator computes current aggregates
   - WebSocket handler broadcasts to dashboard room
   - Frontend receives updates and renders charts

4. **Persistence**
   - Raw events stored in `events` collection
   - Aggregates stored in `aggregates` collection
   - TTL indexes for automatic cleanup

## Configuration

All configuration in `backend/src/config/index.js`:
- Server port
- MongoDB connection
- JWT settings
- CORS origin
- Rate limits
- Aggregation windows
- Logging level

Environment variables (see `backend/.env.example`):
- `NODE_ENV`
- `PORT`
- `MONGODB_URI`
- `JWT_SECRET`
- `CORS_ORIGIN`
- Rate limit settings
- Log level

## Security Features

- JWT authentication (optional for demo)
- CORS protection
- Input validation (Joi schemas)
- Rate limiting (per client and endpoint)
- Message size limits
- Origin checks

## Performance Features

- Batch processing
- In-memory aggregation
- Delta updates (minimal bandwidth)
- Connection pooling
- Automatic cleanup
- Indexed database queries

## Observability

- Structured logging (Winston)
- Health/readiness endpoints
- Connection metrics
- Error tracking
- Correlation IDs (in logs)

