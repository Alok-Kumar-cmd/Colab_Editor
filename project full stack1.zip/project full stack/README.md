# Real-Time Analytics Dashboard

A full-stack real-time analytics system with WebSocket streaming, MongoDB persistence, and live-updating charts.

## Features

- **Real-time Event Ingestion**: WebSocket and REST API for event streaming
- **Rolling Aggregates**: Server-side computation of 1s/5s/60s windows
- **Live Dashboard**: React + Chart.js visualizations with real-time updates
- **MongoDB Persistence**: Raw events and materialized aggregates
- **Security**: JWT authentication, CORS, input validation
- **Resilience**: Reconnect handling, rate limiting, backpressure control
- **Observability**: Metrics, structured logging, health endpoints

## Architecture

- **Backend**: Node.js + Express + Socket.io
- **Frontend**: React + Chart.js
- **Database**: MongoDB
- **Transport**: WebSocket (primary) + REST (fallback)

## Quick Start

### Prerequisites

- Node.js 18+
- Docker & Docker Compose
- npm or yarn

### Installation

#### Option 1: Using Make (Recommended)

```bash
# Install dependencies and start MongoDB
make setup

# Start development servers
make dev
```

#### Option 2: Manual Setup

1. Install dependencies:
```bash
npm run install:all
```

2. Start MongoDB:
```bash
npm run docker:up
# Or using make: make docker-up
```

3. Create environment file:
```bash
# Copy the example file
cp backend/.env.example backend/.env
# Or create manually with MongoDB connection string
```

4. Start development servers:
```bash
npm run dev
```

Backend will run on `http://localhost:3001`
Frontend will run on `http://localhost:3000`

### Seed Data

```bash
npm run seed
```

### Load Testing

```bash
cd backend && npm run test:load
```

## Project Structure

```
.
├── backend/
│   ├── src/
│   │   ├── server.js          # Main server entry
│   │   ├── config/            # Configuration
│   │   ├── models/            # Data models
│   │   ├── routes/            # REST routes
│   │   ├── services/          # Business logic
│   │   ├── middleware/        # Auth, validation, etc.
│   │   ├── websocket/         # WebSocket handlers
│   │   ├── aggregators/       # Rolling aggregates
│   │   └── scripts/           # Seed, load generator
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── App.js             # Main app component
│   │   ├── components/        # React components
│   │   ├── services/          # API & WebSocket clients
│   │   ├── utils/             # Utilities
│   │   └── index.js
│   └── package.json
├── docker-compose.yml
└── package.json
```

## API Endpoints

- `POST /api/events` - Ingest events (REST fallback)
- `GET /api/metrics` - Get current metrics
- `GET /api/health` - Health check
- `GET /api/ready` - Readiness check
- `WebSocket /` - Real-time event streaming and dashboard updates

## Dashboard Views

- Active Users (real-time count)
- Events per Second
- Top Routes
- Error Rates
- Custom time-range filtering

## Environment Variables

See `backend/.env.example` for all configuration options.

## License

MIT

