# Quick Start Guide

## Prerequisites

- Node.js 18+ and npm
- Docker and Docker Compose
- Git

## Step-by-Step Setup

### 1. Clone and Install

```bash
# Install all dependencies
npm run install:all
# Or: make install
```

### 2. Start MongoDB

```bash
# Start MongoDB container
npm run docker:up
# Or: make docker-up
# Or: docker-compose up -d
```

Wait a few seconds for MongoDB to be ready.

### 3. Configure Environment

Create `backend/.env` file:

```bash
cp backend/.env.example backend/.env
```

Or create manually with these minimal settings:

```
NODE_ENV=development
PORT=3001
MONGODB_URI=mongodb://admin:admin123@localhost:27017/analytics?authSource=admin
JWT_SECRET=your-secret-key-here
CORS_ORIGIN=http://localhost:3000
```

### 4. Seed Database (Optional)

```bash
npm run seed
# Or: make seed
```

This populates the database with sample events for testing.

### 5. Start Development Servers

```bash
npm run dev
# Or: make dev
```

This starts both backend and frontend concurrently.

### 6. Access the Dashboard

Open your browser to: `http://localhost:3000`

## Using the Dashboard

### Generate Test Events

1. Use the Event Generator component at the top of the page
2. Click "Start" to begin generating events
3. Watch the charts update in real-time

### Load Testing

In a separate terminal:

```bash
cd backend
npm run test:load
# Or: make load-test
```

This will simulate multiple clients sending events.

## API Endpoints

### REST API

- `POST /api/events` - Send a single event
- `POST /api/events/batch` - Send multiple events
- `GET /api/events` - Query events
- `GET /api/metrics` - Get current metrics
- `GET /api/health` - Health check
- `GET /api/ready` - Readiness check

### WebSocket

- Connect to: `ws://localhost:3001`
- Events:
  - `event` - Send single event
  - `events` - Send batch events
  - `subscribe` - Subscribe to channels
  - `metrics:update` - Receive metric updates

## Troubleshooting

### MongoDB Connection Issues

```bash
# Check if MongoDB is running
docker ps

# Restart MongoDB
docker-compose restart

# Check logs
docker-compose logs mongodb
```

### Port Already in Use

Change ports in:
- Backend: `backend/.env` (PORT)
- Frontend: `frontend/.env` (REACT_APP_API_URL)

### Clear and Reset

```bash
# Stop containers
make docker-down

# Remove volumes (clears data)
docker-compose down -v

# Restart
make docker-up
make seed
```

## Next Steps

- Review the main README.md for architecture details
- Check the code structure in `backend/src` and `frontend/src`
- Customize charts and metrics in `frontend/src/components/Dashboard.js`
- Adjust aggregation windows in `backend/src/config/index.js`

