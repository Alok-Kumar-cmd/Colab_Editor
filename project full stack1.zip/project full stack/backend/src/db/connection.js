const { MongoClient } = require('mongodb');
const config = require('../config');
const logger = require('../utils/logger');

let client = null;
let db = null;

async function connect() {
  if (db) {
    return db;
  }

  try {
    client = new MongoClient(config.mongodb.uri, {
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 5000,
    });

    await client.connect();
    db = client.db('analytics');
    logger.info('Connected to MongoDB');

    // Create indexes
    await db.collection('events').createIndex({ timestamp: 1 });
    await db.collection('events').createIndex({ eventId: 1 }, { unique: true });
    await db.collection('events').createIndex({ userId: 1 });
    await db.collection('events').createIndex({ sessionId: 1 });
    await db.collection('events').createIndex({ route: 1 });
    await db.collection('events').createIndex({ createdAt: 1 }, { expireAfterSeconds: 86400 * 7 }); // 7 day TTL

    await db.collection('aggregates').createIndex({ window: 1, timestamp: 1 });
    await db.collection('aggregates').createIndex({ timestamp: 1 }, { expireAfterSeconds: 86400 * 30 }); // 30 day TTL

    logger.info('Database indexes created');
    return db;
  } catch (error) {
    logger.error('MongoDB connection error', { error: error.message });
    throw error;
  }
}

async function disconnect() {
  if (client) {
    await client.close();
    client = null;
    db = null;
    logger.info('Disconnected from MongoDB');
  }
}

function getDb() {
  if (!db) {
    throw new Error('Database not connected. Call connect() first.');
  }
  return db;
}

module.exports = {
  connect,
  disconnect,
  getDb,
};

