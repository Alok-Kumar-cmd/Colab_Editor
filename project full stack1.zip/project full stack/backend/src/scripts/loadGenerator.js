const io = require('socket.io-client');
const { v4: uuidv4 } = require('uuid');

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3001';
const NUM_CLIENTS = parseInt(process.argv[2] || '5', 10);
const EVENTS_PER_CLIENT = parseInt(process.argv[3] || '100', 10);
const INTERVAL_MS = parseInt(process.argv[4] || '100', 10);

const routes = ['/home', '/dashboard', '/profile', '/settings', '/api/users', '/api/data'];
const actions = ['view', 'click', 'submit', 'error', 'navigation'];

function generateEvent(userId, sessionId) {
  return {
    eventId: uuidv4(),
    timestamp: Date.now(),
    userId,
    sessionId,
    route: routes[Math.floor(Math.random() * routes.length)],
    action: actions[Math.floor(Math.random() * actions.length)],
    metadata: {
      loadTest: true,
      userAgent: 'LoadGenerator/1.0',
    },
  };
}

function createClient(clientId) {
  const socket = io(BACKEND_URL, {
    transports: ['websocket'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    reconnectionAttempts: Infinity,
  });

  const userId = `load-user-${clientId}`;
  const sessionId = `load-session-${clientId}`;
  let eventCount = 0;
  let successCount = 0;
  let errorCount = 0;

  socket.on('connect', () => {
    console.log(`[Client ${clientId}] Connected`);
    
    const interval = setInterval(() => {
      if (eventCount >= EVENTS_PER_CLIENT) {
        clearInterval(interval);
        socket.disconnect();
        console.log(`[Client ${clientId}] Completed: ${successCount} success, ${errorCount} errors`);
        return;
      }

      const event = generateEvent(userId, sessionId);
      socket.emit('event', event);
      eventCount++;
    }, INTERVAL_MS);
  });

  socket.on('event:ack', () => {
    successCount++;
  });

  socket.on('error', (error) => {
    errorCount++;
    console.error(`[Client ${clientId}] Error:`, error);
  });

  socket.on('disconnect', () => {
    console.log(`[Client ${clientId}] Disconnected`);
  });

  socket.on('connect_error', (error) => {
    console.error(`[Client ${clientId}] Connection error:`, error.message);
  });

  return socket;
}

console.log(`Starting load test: ${NUM_CLIENTS} clients, ${EVENTS_PER_CLIENT} events each, ${INTERVAL_MS}ms interval`);
console.log(`Connecting to ${BACKEND_URL}`);

const clients = [];
for (let i = 0; i < NUM_CLIENTS; i++) {
  clients.push(createClient(i + 1));
}

// Run for a maximum of 10 minutes
setTimeout(() => {
  console.log('Load test timeout, shutting down...');
  clients.forEach(client => client.disconnect());
  process.exit(0);
}, 600000);

