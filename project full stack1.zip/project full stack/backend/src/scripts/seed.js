const { connect, disconnect, getDb } = require('../db/connection');
const Event = require('../models/Event');
const logger = require('../utils/logger');

const routes = ['/home', '/dashboard', '/profile', '/settings', '/api/users', '/api/data'];
const actions = ['view', 'click', 'submit', 'error', 'navigation'];
const users = Array.from({ length: 50 }, (_, i) => `user-${i + 1}`);
const sessions = Array.from({ length: 100 }, (_, i) => `session-${i + 1}`);

function generateEvent() {
  const now = Date.now();
  const randomTime = now - Math.random() * 86400000; // Random time in last 24 hours

  return {
    userId: users[Math.floor(Math.random() * users.length)],
    sessionId: sessions[Math.floor(Math.random() * sessions.length)],
    route: routes[Math.floor(Math.random() * routes.length)],
    action: actions[Math.floor(Math.random() * actions.length)],
    timestamp: randomTime,
    metadata: {
      userAgent: 'Mozilla/5.0',
      ip: `192.168.1.${Math.floor(Math.random() * 255)}`,
    },
  };
}

async function seed() {
  try {
    await connect();
    const db = getDb();

    logger.info('Starting seed...');
    
    // Clear existing data (optional)
    const clear = process.argv.includes('--clear');
    if (clear) {
      logger.info('Clearing existing data...');
      await db.collection('events').deleteMany({});
      await db.collection('aggregates').deleteMany({});
    }

    const batchSize = 1000;
    const totalEvents = parseInt(process.argv[2] || '10000', 10);
    let inserted = 0;

    logger.info(`Generating ${totalEvents} events...`);

    while (inserted < totalEvents) {
      const events = [];
      const batchCount = Math.min(batchSize, totalEvents - inserted);

      for (let i = 0; i < batchCount; i++) {
        events.push(new Event(generateEvent()).toJSON());
      }

      await db.collection('events').insertMany(events);
      inserted += batchCount;

      logger.info(`Inserted ${inserted}/${totalEvents} events`);
    }

    logger.info('Seed completed successfully');
    await disconnect();
    process.exit(0);
  } catch (error) {
    logger.error('Seed error', { error: error.message });
    await disconnect();
    process.exit(1);
  }
}

seed();

