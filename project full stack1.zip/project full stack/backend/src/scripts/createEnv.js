const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '..', '.env');
const examplePath = path.join(__dirname, '..', '.env.example');

if (fs.existsSync(envPath)) {
  console.log('.env file already exists');
  process.exit(0);
}

if (!fs.existsSync(examplePath)) {
  console.error('.env.example not found');
  process.exit(1);
}

fs.copyFileSync(examplePath, envPath);
console.log('.env file created from .env.example');

