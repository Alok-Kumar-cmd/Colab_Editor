const Event = require('../models/Event');
const { getDb } = require('../db/connection');
const logger = require('../utils/logger');

class EventService {
  async ingestEvent(eventData) {
    const db = getDb();
    const event = new Event(eventData);

    // Check for duplicate eventId (idempotency)
    const existing = await db.collection('events').findOne({ eventId: event.eventId });
    if (existing) {
      logger.debug('Duplicate eventId detected', { eventId: event.eventId });
      return existing;
    }

    // Insert event
    await db.collection('events').insertOne(event.toJSON());
    logger.debug('Event ingested', { eventId: event.eventId, route: event.route });

    return event;
  }

  async ingestEvents(eventsData) {
    const db = getDb();
    const events = eventsData.map(data => new Event(data));

    // Filter out duplicates
    const eventIds = events.map(e => e.eventId);
    const existing = await db.collection('events')
      .find({ eventId: { $in: eventIds } })
      .toArray();
    const existingIds = new Set(existing.map(e => e.eventId));
    const newEvents = events.filter(e => !existingIds.has(e.eventId));

    if (newEvents.length === 0) {
      return [];
    }

    const documents = newEvents.map(e => e.toJSON());
    await db.collection('events').insertMany(documents);
    logger.debug('Batch events ingested', { count: newEvents.length });

    return newEvents;
  }

  async getEvents(query = {}, limit = 100) {
    const db = getDb();
    return await db.collection('events')
      .find(query)
      .sort({ timestamp: -1 })
      .limit(limit)
      .toArray();
  }

  async getEventCount(query = {}) {
    const db = getDb();
    return await db.collection('events').countDocuments(query);
  }
}

module.exports = new EventService();

