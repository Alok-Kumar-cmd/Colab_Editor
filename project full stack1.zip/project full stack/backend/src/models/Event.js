const { v4: uuidv4 } = require('uuid');

class Event {
  constructor(data) {
    this.id = data.id || uuidv4();
    this.eventId = data.eventId || uuidv4(); // Client-provided event ID for idempotency
    this.timestamp = data.timestamp || Date.now();
    this.userId = data.userId;
    this.sessionId = data.sessionId;
    this.route = data.route;
    this.action = data.action;
    this.metadata = data.metadata || {};
    this.createdAt = data.createdAt || new Date();
  }

  toJSON() {
    return {
      id: this.id,
      eventId: this.eventId,
      timestamp: this.timestamp,
      userId: this.userId,
      sessionId: this.sessionId,
      route: this.route,
      action: this.action,
      metadata: this.metadata,
      createdAt: this.createdAt,
    };
  }

  static fromJSON(data) {
    return new Event(data);
  }
}

module.exports = Event;

