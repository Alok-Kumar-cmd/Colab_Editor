require('dotenv').config();

module.exports = {
  env: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '3001', 10),
  mongodb: {
    uri: process.env.MONGODB_URI || 'mongodb://admin:admin123@localhost:27017/analytics?authSource=admin',
  },
  jwt: {
    secret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  },
  cors: {
    origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  },
  websocket: {
    maxMessageSize: parseInt(process.env.WS_MAX_MESSAGE_SIZE || '100000', 10),
    rateLimitWindow: parseInt(process.env.WS_RATE_LIMIT_WINDOW || '60000', 10),
    rateLimitMax: parseInt(process.env.WS_RATE_LIMIT_MAX || '1000', 10),
  },
  rest: {
    rateLimitWindow: parseInt(process.env.REST_RATE_LIMIT_WINDOW || '60000', 10),
    rateLimitMax: parseInt(process.env.REST_RATE_LIMIT_MAX || '100', 10),
  },
  logging: {
    level: process.env.LOG_LEVEL || 'info',
  },
  aggregates: {
    windows: [1000, 5000, 60000], // 1s, 5s, 60s in milliseconds
    updateInterval: 100, // Emit updates every 100ms
  },
};

