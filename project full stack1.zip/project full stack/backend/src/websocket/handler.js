const { Server } = require('socket.io');
const { authenticateSocket } = require('../middleware/auth');
const { validateEventData } = require('../middleware/validation');
const eventService = require('../services/eventService');
const RollingAggregator = require('../aggregators/rollingAggregator');
const config = require('../config');
const logger = require('../utils/logger');

class WebSocketHandler {
  constructor(httpServer, aggregator = null) {
    this.io = new Server(httpServer, {
      cors: {
        origin: config.cors.origin,
        methods: ['GET', 'POST'],
      },
      maxHttpBufferSize: config.websocket.maxMessageSize,
      pingTimeout: 60000,
      pingInterval: 25000,
    });

    this.aggregator = aggregator || new RollingAggregator(config.aggregates.windows);
    this.connectedClients = new Map(); // clientId -> { socket, lastUpdate }
    this.subscriptions = new Map(); // clientId -> Set<channels>
    this.rateLimiters = new Map(); // clientId -> { count, resetTime }

    this.setupMiddleware();
    this.setupEventHandlers();
    this.startBroadcastLoop();
    this.startPersistenceLoop();
  }

  setupMiddleware() {
    this.io.use(authenticateSocket);
  }

  setupEventHandlers() {
    this.io.on('connection', (socket) => {
      const clientId = socket.id;
      logger.info('Client connected', { clientId, user: socket.user?.id });

      this.connectedClients.set(clientId, {
        socket,
        lastUpdate: Date.now(),
        subscriptions: new Set(['dashboard']), // Default subscription
      });

      // Subscribe to dashboard updates
      socket.join('dashboard');

      // Handle event ingestion
      socket.on('event', async (data) => {
        await this.handleEventIngest(socket, data);
      });

      // Handle batch event ingestion
      socket.on('events', async (data) => {
        await this.handleBatchIngest(socket, data);
      });

      // Handle subscription changes
      socket.on('subscribe', (channels) => {
        this.handleSubscription(socket, channels);
      });

      // Handle disconnect
      socket.on('disconnect', () => {
        this.handleDisconnect(clientId);
      });

      // Handle errors
      socket.on('error', (error) => {
        logger.error('Socket error', { clientId, error: error.message });
      });

      // Send initial state
      this.sendInitialState(socket);
    });
  }

  async handleEventIngest(socket, data) {
    const clientId = socket.id;
    
    // Rate limiting
    if (!this.checkRateLimit(clientId)) {
      socket.emit('error', { message: 'Rate limit exceeded' });
      return;
    }

    // Validate
    const validation = validateEventData(data);
    if (validation.error) {
      socket.emit('error', { message: 'Validation failed', details: validation.error });
      return;
    }

    try {
      // Normalize timestamp
      const eventData = {
        ...validation.value,
        timestamp: validation.value.timestamp || Date.now(),
        eventId: validation.value.eventId || require('uuid').v4(),
      };

      // Ingest event
      const event = await eventService.ingestEvent(eventData);

      // Update aggregator
      this.aggregator.addEvent(event);

      // Acknowledge
      socket.emit('event:ack', { eventId: event.eventId });

      // Update metrics
      this.updateMetrics(clientId);
    } catch (error) {
      logger.error('Event ingest error', { clientId, error: error.message });
      socket.emit('error', { message: 'Failed to ingest event' });
    }
  }

  async handleBatchIngest(socket, data) {
    const clientId = socket.id;
    const events = Array.isArray(data) ? data : [data];

    if (events.length > 100) {
      socket.emit('error', { message: 'Batch size too large (max 100)' });
      return;
    }

    // Rate limiting (check per event)
    if (!this.checkRateLimit(clientId, events.length)) {
      socket.emit('error', { message: 'Rate limit exceeded' });
      return;
    }

    try {
      const validatedEvents = [];
      for (const eventData of events) {
        const validation = validateEventData(eventData);
        if (!validation.error) {
          validatedEvents.push({
            ...validation.value,
            timestamp: validation.value.timestamp || Date.now(),
            eventId: validation.value.eventId || require('uuid').v4(),
          });
        }
      }

      if (validatedEvents.length === 0) {
        socket.emit('error', { message: 'No valid events in batch' });
        return;
      }

      const ingested = await eventService.ingestEvents(validatedEvents);
      ingested.forEach(event => this.aggregator.addEvent(event));

      socket.emit('events:ack', { count: ingested.length });
      this.updateMetrics(clientId);
    } catch (error) {
      logger.error('Batch ingest error', { clientId, error: error.message });
      socket.emit('error', { message: 'Failed to ingest batch' });
    }
  }

  handleSubscription(socket, channels) {
    const clientId = socket.id;
    const channelList = Array.isArray(channels) ? channels : [channels];

    channelList.forEach(channel => {
      socket.join(channel);
      const client = this.connectedClients.get(clientId);
      if (client) {
        client.subscriptions.add(channel);
      }
    });

    socket.emit('subscribed', { channels: channelList });
  }

  handleDisconnect(clientId) {
    logger.info('Client disconnected', { clientId });
    this.connectedClients.delete(clientId);
    this.subscriptions.delete(clientId);
    this.rateLimiters.delete(clientId);
  }

  checkRateLimit(clientId, count = 1) {
    const now = Date.now();
    const limiter = this.rateLimiters.get(clientId) || { count: 0, resetTime: now + config.websocket.rateLimitWindow };

    if (now > limiter.resetTime) {
      limiter.count = 0;
      limiter.resetTime = now + config.websocket.rateLimitWindow;
    }

    limiter.count += count;

    if (limiter.count > config.websocket.rateLimitMax) {
      return false;
    }

    this.rateLimiters.set(clientId, limiter);
    return true;
  }

  updateMetrics(clientId) {
    const client = this.connectedClients.get(clientId);
    if (client) {
      client.lastUpdate = Date.now();
    }
  }

  async sendInitialState(socket) {
    const aggregates = this.aggregator.getAllAggregates();
    socket.emit('metrics:update', { aggregates });
  }

  startBroadcastLoop() {
    setInterval(() => {
      const aggregates = this.aggregator.getAllAggregates();
      this.io.to('dashboard').emit('metrics:update', { aggregates });
    }, config.aggregates.updateInterval);
  }

  startPersistenceLoop() {
    setInterval(async () => {
      try {
        await this.aggregator.persistAggregates();
      } catch (error) {
        logger.error('Persistence error', { error: error.message });
      }
    }, 5000); // Persist every 5 seconds
  }

  getMetrics() {
    return {
      connectedClients: this.connectedClients.size,
      aggregatorWindows: this.aggregator.windows,
      currentAggregates: this.aggregator.getAllAggregates(),
    };
  }
}

module.exports = WebSocketHandler;

