const { getDb } = require('../db/connection');
const logger = require('../utils/logger');

class RollingAggregator {
  constructor(windows = [1000, 5000, 60000]) {
    this.windows = windows; // milliseconds
    this.counts = new Map(); // window -> Map<timestamp, count>
    this.uniques = new Map(); // window -> Map<timestamp, Set<userId>>
    this.routes = new Map(); // window -> Map<timestamp, Map<route, count>>
    this.errors = new Map(); // window -> Map<timestamp, count>
    this.lastUpdate = new Map(); // window -> timestamp

    this.windows.forEach(window => {
      this.counts.set(window, new Map());
      this.uniques.set(window, new Map());
      this.routes.set(window, new Map());
      this.errors.set(window, new Map());
      this.lastUpdate.set(window, Date.now());
    });

    this.startCleanup();
  }

  addEvent(event) {
    const now = Date.now();
    const timestamp = event.timestamp || now;

    this.windows.forEach(window => {
      const windowStart = Math.floor(timestamp / window) * window;

      // Update counts
      const counts = this.counts.get(window);
      counts.set(windowStart, (counts.get(windowStart) || 0) + 1);

      // Update uniques
      const uniques = this.uniques.get(window);
      if (!uniques.has(windowStart)) {
        uniques.set(windowStart, new Set());
      }
      uniques.get(windowStart).add(event.userId);

      // Update routes
      const routes = this.routes.get(window);
      if (!routes.has(windowStart)) {
        routes.set(windowStart, new Map());
      }
      const routeCounts = routes.get(windowStart);
      routeCounts.set(event.route, (routeCounts.get(event.route) || 0) + 1);

      // Update errors
      if (event.action === 'error' || event.metadata?.error) {
        const errors = this.errors.get(window);
        errors.set(windowStart, (errors.get(windowStart) || 0) + 1);
      }
    });
  }

  getAggregates(window, currentTime = Date.now()) {
    const windowStart = Math.floor(currentTime / window) * window;
    const counts = this.counts.get(window);
    const uniques = this.uniques.get(window);
    const routes = this.routes.get(window);
    const errors = this.errors.get(window);

    const activeWindows = Array.from(counts.keys()).filter(
      ts => ts >= windowStart - window && ts <= windowStart
    );

    let totalCount = 0;
    const uniqueUsers = new Set();
    const routeCounts = new Map();
    let errorCount = 0;

    activeWindows.forEach(ts => {
      totalCount += counts.get(ts) || 0;
      const uniqueSet = uniques.get(ts);
      if (uniqueSet) {
        uniqueSet.forEach(userId => uniqueUsers.add(userId));
      }
      const routeMap = routes.get(ts);
      if (routeMap) {
        routeMap.forEach((count, route) => {
          routeCounts.set(route, (routeCounts.get(route) || 0) + count);
        });
      }
      errorCount += errors.get(ts) || 0;
    });

    // Sort routes by count
    const topRoutes = Array.from(routeCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([route, count]) => ({ route, count }));

    return {
      window,
      timestamp: currentTime,
      count: totalCount,
      uniqueUsers: uniqueUsers.size,
      eventsPerSecond: totalCount / (window / 1000),
      topRoutes,
      errorCount,
      errorRate: totalCount > 0 ? errorCount / totalCount : 0,
    };
  }

  getAllAggregates(currentTime = Date.now()) {
    return this.windows.map(window => this.getAggregates(window, currentTime));
  }

  getDeltaUpdates(window, lastTimestamp, currentTime = Date.now()) {
    const windowStart = Math.floor(currentTime / window) * window;
    const lastWindowStart = Math.floor(lastTimestamp / window) * window;

    const newWindows = Array.from(this.counts.get(window).keys()).filter(
      ts => ts > lastWindowStart && ts <= windowStart
    );

    if (newWindows.length === 0) {
      return null;
    }

    return this.getAggregates(window, currentTime);
  }

  // Cleanup old windows (keep only last 2 windows per aggregation)
  startCleanup() {
    setInterval(() => {
      const now = Date.now();
      this.windows.forEach(window => {
        const cutoff = Math.floor(now / window) * window - window * 2;

        [this.counts, this.uniques, this.routes, this.errors].forEach(store => {
          const map = store.get(window);
          Array.from(map.keys()).forEach(ts => {
            if (ts < cutoff) {
              map.delete(ts);
            }
          });
        });
      });
    }, 60000); // Cleanup every minute
  }

  async persistAggregates() {
    const db = getDb();
    const aggregates = this.getAllAggregates();
    const now = Date.now();

    const documents = aggregates.map(agg => ({
      ...agg,
      _id: `${agg.window}-${Math.floor(now / agg.window) * agg.window}`,
      persistedAt: now,
    }));

    if (documents.length > 0) {
      const operations = documents.map(doc => ({
        updateOne: {
          filter: { _id: doc._id },
          update: { $set: doc },
          upsert: true,
        },
      }));

      await db.collection('aggregates').bulkWrite(operations);
      logger.debug('Aggregates persisted', { count: documents.length });
    }
  }
}

module.exports = RollingAggregator;

