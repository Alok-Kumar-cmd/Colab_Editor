const express = require('express');
const { generateToken } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// Demo auth endpoint (for development/testing)
// In production, this should use proper authentication
router.post('/auth/demo', (req, res) => {
  try {
    const userId = req.body.userId || 'demo-user';
    const role = req.body.role || 'user';

    const token = generateToken({ id: userId, role });
    
    res.json({
      success: true,
      token,
      user: { id: userId, role },
    });
  } catch (error) {
    logger.error('Auth error', { error: error.message });
    res.status(500).json({ error: 'Failed to generate token' });
  }
});

module.exports = router;

