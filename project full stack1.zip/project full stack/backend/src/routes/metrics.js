const express = require('express');
const { getDb } = require('../db/connection');
const logger = require('../utils/logger');

const router = express.Router();

// Get current metrics
router.get('/metrics', async (req, res) => {
  try {
    const db = getDb();
    
    // Get current aggregates from database
    const aggregates = await db.collection('aggregates')
      .find({})
      .sort({ timestamp: -1 })
      .limit(3)
      .toArray();

    // Get basic stats
    const totalEvents = await db.collection('events').countDocuments();
    const uniqueUsers = await db.collection('events').distinct('userId').then(arr => arr.length);
    const uniqueSessions = await db.collection('events').distinct('sessionId').then(arr => arr.length);

    res.json({
      aggregates,
      stats: {
        totalEvents,
        uniqueUsers,
        uniqueSessions,
      },
    });
  } catch (error) {
    logger.error('Get metrics error', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch metrics' });
  }
});

module.exports = router;

