const express = require('express');
const rateLimit = require('express-rate-limit');
const { validateEvent } = require('../middleware/validation');
const eventService = require('../services/eventService');
const config = require('../config');
const logger = require('../utils/logger');

const router = express.Router();

// Rate limiting
const limiter = rateLimit({
  windowMs: config.rest.rateLimitWindow,
  max: config.rest.rateLimitMax,
  message: 'Too many requests, please try again later.',
});

// Ingest single event (REST fallback)
router.post('/events', limiter, validateEvent, async (req, res) => {
  try {
    const eventData = {
      ...req.validatedEvent,
      timestamp: req.validatedEvent.timestamp || Date.now(),
      eventId: req.validatedEvent.eventId || require('uuid').v4(),
    };

    const event = await eventService.ingestEvent(eventData);
    
    // Update aggregator if available
    const aggregator = req.app.get('aggregator');
    if (aggregator) {
      aggregator.addEvent(event);
    }
    
    res.status(201).json({
      success: true,
      eventId: event.eventId,
    });
  } catch (error) {
    logger.error('Event ingestion error', { error: error.message });
    res.status(500).json({ error: 'Failed to ingest event' });
  }
});

// Ingest batch events
router.post('/events/batch', limiter, async (req, res) => {
  try {
    const events = Array.isArray(req.body) ? req.body : [req.body];
    
    if (events.length > 100) {
      return res.status(400).json({ error: 'Batch size too large (max 100)' });
    }

    const { validateEventData } = require('../middleware/validation');
    const validatedEvents = [];
    
    for (const eventData of events) {
      const validation = validateEventData(eventData);
      if (!validation.error) {
        validatedEvents.push({
          ...validation.value,
          timestamp: validation.value.timestamp || Date.now(),
          eventId: validation.value.eventId || require('uuid').v4(),
        });
      }
    }

    if (validatedEvents.length === 0) {
      return res.status(400).json({ error: 'No valid events in batch' });
    }

    const ingested = await eventService.ingestEvents(validatedEvents);
    
    // Update aggregator if available
    const aggregator = req.app.get('aggregator');
    if (aggregator) {
      ingested.forEach(event => aggregator.addEvent(event));
    }
    
    res.status(201).json({
      success: true,
      count: ingested.length,
    });
  } catch (error) {
    logger.error('Batch ingestion error', { error: error.message });
    res.status(500).json({ error: 'Failed to ingest events' });
  }
});

// Get events (with query)
router.get('/events', async (req, res) => {
  try {
    const query = {};
    if (req.query.userId) query.userId = req.query.userId;
    if (req.query.sessionId) query.sessionId = req.query.sessionId;
    if (req.query.route) query.route = req.query.route;
    if (req.query.startTime) query.timestamp = { $gte: parseInt(req.query.startTime) };
    if (req.query.endTime) {
      query.timestamp = query.timestamp || {};
      query.timestamp.$lte = parseInt(req.query.endTime);
    }

    const limit = parseInt(req.query.limit || '100', 10);
    const events = await eventService.getEvents(query, limit);
    
    res.json({ events });
  } catch (error) {
    logger.error('Get events error', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

module.exports = router;

