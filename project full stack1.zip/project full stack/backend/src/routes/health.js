const express = require('express');
const { getDb } = require('../db/connection');

const router = express.Router();

// Health check
router.get('/health', async (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: Date.now(),
  });
});

// Readiness check
router.get('/ready', async (req, res) => {
  try {
    const db = getDb();
    await db.admin().ping();
    res.json({
      status: 'ready',
      timestamp: Date.now(),
      database: 'connected',
    });
  } catch (error) {
    res.status(503).json({
      status: 'not ready',
      timestamp: Date.now(),
      database: 'disconnected',
      error: error.message,
    });
  }
});

module.exports = router;

