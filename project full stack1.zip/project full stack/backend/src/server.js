const express = require('express');
const http = require('http');
const cors = require('cors');
const config = require('./config');
const logger = require('./utils/logger');
const { connect, disconnect } = require('./db/connection');
const WebSocketHandler = require('./websocket/handler');
const RollingAggregator = require('./aggregators/rollingAggregator');
const eventRoutes = require('./routes/events');
const metricsRoutes = require('./routes/metrics');
const healthRoutes = require('./routes/health');
const authRoutes = require('./routes/auth');

const app = express();
const server = http.createServer(app);

// Middleware
app.use(cors({ origin: config.cors.origin }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api', healthRoutes);
app.use('/api', authRoutes);
app.use('/api', eventRoutes);
app.use('/api', metricsRoutes);

// Initialize WebSocket and shared aggregator
let wsHandler = null;
let aggregator = null;

// Make aggregator available to routes
app.set('aggregator', aggregator);

// Error handling
app.use((err, req, res, next) => {
  logger.error('Unhandled error', { error: err.message, stack: err.stack });
  res.status(500).json({ error: 'Internal server error' });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  await disconnect();
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received, shutting down gracefully');
  await disconnect();
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

// Start server
async function start() {
  try {
    await connect();
    aggregator = new RollingAggregator(config.aggregates.windows);
    app.set('aggregator', aggregator);
    wsHandler = new WebSocketHandler(server, aggregator); // Share aggregator instance
    
    server.listen(config.port, () => {
      logger.info(`Server running on port ${config.port}`);
      logger.info(`Environment: ${config.env}`);
    });
  } catch (error) {
    logger.error('Failed to start server', { error: error.message });
    process.exit(1);
  }
}

start();

module.exports = { app, server };

