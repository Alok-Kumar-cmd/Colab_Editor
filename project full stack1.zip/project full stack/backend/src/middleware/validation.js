const Joi = require('joi');
const logger = require('../utils/logger');

const eventSchema = Joi.object({
  eventId: Joi.string().uuid().optional(),
  timestamp: Joi.number().integer().min(0).optional(),
  userId: Joi.string().min(1).max(255).required(),
  sessionId: Joi.string().min(1).max(255).required(),
  route: Joi.string().min(1).max(255).required(),
  action: Joi.string().min(1).max(100).required(),
  metadata: Joi.object().optional().default({}),
});

function validateEvent(req, res, next) {
  const { error, value } = eventSchema.validate(req.body, {
    abortEarly: false,
    stripUnknown: true,
  });

  if (error) {
    logger.warn('Event validation failed', { error: error.details });
    return res.status(400).json({
      error: 'Validation failed',
      details: error.details.map(d => d.message),
    });
  }

  req.validatedEvent = value;
  next();
}

function validateEventData(data) {
  const { error, value } = eventSchema.validate(data, {
    abortEarly: false,
    stripUnknown: true,
  });

  if (error) {
    return { error: error.details.map(d => d.message) };
  }

  return { value };
}

module.exports = {
  validateEvent,
  validateEventData,
};

