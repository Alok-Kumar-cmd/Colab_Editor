const jwt = require('jsonwebtoken');
const config = require('../config');
const logger = require('../utils/logger');

function authenticateToken(req, res, next) {
  // Skip auth for health endpoints
  if (req.path === '/health' || req.path === '/ready') {
    return next();
  }

  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    // For demo purposes, allow unauthenticated access
    // In production, you should require authentication
    logger.info('Request without auth token (allowed for demo)');
    req.user = { id: 'anonymous', role: 'guest' };
    return next();
  }

  jwt.verify(token, config.jwt.secret, (err, user) => {
    if (err) {
      logger.warn('JWT verification failed', { error: err.message });
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
}

function authenticateSocket(socket, next) {
  const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];

  if (!token) {
    // For demo purposes, allow unauthenticated connections
    // In production, you should require authentication
    logger.info('Socket connection without auth token (allowed for demo)');
    socket.user = { id: 'anonymous', role: 'guest' };
    return next();
  }

  jwt.verify(token, config.jwt.secret, (err, user) => {
    if (err) {
      logger.warn('Socket JWT verification failed', { error: err.message });
      return next(new Error('Authentication failed'));
    }
    socket.user = user;
    next();
  });
}

function generateToken(user) {
  return jwt.sign(
    { id: user.id || user.userId, role: user.role || 'user' },
    config.jwt.secret,
    { expiresIn: config.jwt.expiresIn }
  );
}

module.exports = {
  authenticateToken,
  authenticateSocket,
  generateToken,
};
