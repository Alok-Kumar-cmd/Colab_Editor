import React from 'react';
import Dashboard from './components/Dashboard';
import EventGenerator from './components/EventGenerator';
import './App.css';

function App() {
  return (
    <div className="App">
      <EventGenerator />
      <Dashboard />
    </div>
  );
}

export default App;

