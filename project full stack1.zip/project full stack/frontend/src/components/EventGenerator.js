import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import websocketService from '../services/websocket';
import { sendEvent } from '../services/api';
import './EventGenerator.css';

const EventGenerator = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [interval, setInterval] = useState(1000);
  const [eventsSent, setEventsSent] = useState(0);
  const [errors, setErrors] = useState(0);
  const [userId, setUserId] = useState(`user-${Math.random().toString(36).substr(2, 9)}`);
  const [sessionId, setSessionId] = useState(`session-${Math.random().toString(36).substr(2, 9)}`);

  const routes = ['/home', '/dashboard', '/profile', '/settings', '/api/users', '/api/data'];
  const actions = ['view', 'click', 'submit', 'error', 'navigation'];

  const generateEvent = () => {
    return {
      eventId: uuidv4(),
      timestamp: Date.now(),
      userId,
      sessionId,
      route: routes[Math.floor(Math.random() * routes.length)],
      action: actions[Math.floor(Math.random() * actions.length)],
      metadata: {
        userAgent: navigator.userAgent,
        source: 'demo',
      },
    };
  };

  useEffect(() => {
    let intervalId = null;

    if (isGenerating) {
      const sendEventData = async () => {
        try {
          const event = generateEvent();
          if (websocketService.isConnected()) {
            websocketService.sendEvent(event);
          } else {
            await sendEvent(event);
          }
          setEventsSent(prev => prev + 1);
        } catch (error) {
          console.error('Error sending event:', error);
          setErrors(prev => prev + 1);
        }
      };

      intervalId = setInterval(sendEventData, interval);
      sendEventData(); // Send immediately
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [isGenerating, interval, userId, sessionId]);

  const handleStart = () => {
    setIsGenerating(true);
    setEventsSent(0);
    setErrors(0);
  };

  const handleStop = () => {
    setIsGenerating(false);
  };

  return (
    <div className="event-generator">
      <h2>Event Generator (Demo)</h2>
      <div className="generator-controls">
        <div className="control-group">
          <label>User ID:</label>
          <input
            type="text"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            disabled={isGenerating}
          />
        </div>
        <div className="control-group">
          <label>Session ID:</label>
          <input
            type="text"
            value={sessionId}
            onChange={(e) => setSessionId(e.target.value)}
            disabled={isGenerating}
          />
        </div>
        <div className="control-group">
          <label>Interval (ms):</label>
          <input
            type="number"
            value={interval}
            onChange={(e) => setInterval(parseInt(e.target.value, 10))}
            disabled={isGenerating}
            min="100"
            max="10000"
          />
        </div>
        <div className="control-group">
          <button
            onClick={isGenerating ? handleStop : handleStart}
            className={isGenerating ? 'stop-btn' : 'start-btn'}
          >
            {isGenerating ? 'Stop' : 'Start'}
          </button>
        </div>
      </div>
      <div className="generator-stats">
        <div className="stat">
          <span className="stat-label">Events Sent:</span>
          <span className="stat-value">{eventsSent}</span>
        </div>
        <div className="stat">
          <span className="stat-label">Errors:</span>
          <span className="stat-value error">{errors}</span>
        </div>
        <div className="stat">
          <span className="stat-label">Status:</span>
          <span className="stat-value">
            {websocketService.isConnected() ? 'WebSocket' : 'REST'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default EventGenerator;

