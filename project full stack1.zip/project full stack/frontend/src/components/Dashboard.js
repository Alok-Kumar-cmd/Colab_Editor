import React, { useState, useEffect, useRef } from 'react';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import zoomPlugin from 'chartjs-plugin-zoom';
import websocketService from '../services/websocket';
import './Dashboard.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  zoomPlugin
);

const Dashboard = () => {
  const [aggregates, setAggregates] = useState([]);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [error, setError] = useState(null);
  const [timeRange, setTimeRange] = useState(60); // seconds
  const [chartData, setChartData] = useState({
    activeUsers: { labels: [], datasets: [] },
    eventsPerSecond: { labels: [], datasets: [] },
    errorRate: { labels: [], datasets: [] },
    topRoutes: { labels: [], datasets: [] },
  });
  const dataHistoryRef = useRef({
    activeUsers: [],
    eventsPerSecond: [],
    errorRate: [],
    timestamps: [],
  });

  useEffect(() => {
    // Connect WebSocket
    websocketService.connect();

    // Subscribe to dashboard updates
    websocketService.subscribe(['dashboard']);

    // Listen for metrics updates
    const handleMetricsUpdate = (data) => {
      if (data.aggregates) {
        setAggregates(data.aggregates);
        updateChartData(data.aggregates);
      }
    };

    // Listen for connection status
    const handleConnected = () => {
      setConnectionStatus('connected');
      setError(null);
    };

    const handleDisconnected = () => {
      setConnectionStatus('disconnected');
    };

    const handleError = (err) => {
      setError(err.message || 'Connection error');
      setConnectionStatus('error');
    };

    websocketService.on('metrics:update', handleMetricsUpdate);
    websocketService.on('connected', handleConnected);
    websocketService.on('disconnected', handleDisconnected);
    websocketService.on('error', handleError);

    // Initial connection check
    if (websocketService.isConnected()) {
      setConnectionStatus('connected');
    }

    return () => {
      websocketService.off('metrics:update', handleMetricsUpdate);
      websocketService.off('connected', handleConnected);
      websocketService.off('disconnected', handleDisconnected);
      websocketService.off('error', handleError);
    };
  }, []);

  const updateChartData = (newAggregates) => {
    const now = Date.now();
    const cutoff = now - timeRange * 1000;

    // Use 60s window for display
    const agg60s = newAggregates.find(a => a.window === 60000);
    if (!agg60s) return;

    const timestamp = new Date(agg60s.timestamp).toLocaleTimeString();

    // Update history
    dataHistoryRef.current.activeUsers.push({
      x: agg60s.timestamp,
      y: agg60s.uniqueUsers,
    });
    dataHistoryRef.current.eventsPerSecond.push({
      x: agg60s.timestamp,
      y: agg60s.eventsPerSecond,
    });
    dataHistoryRef.current.errorRate.push({
      x: agg60s.timestamp,
      y: agg60s.errorRate * 100, // Convert to percentage
    });
    dataHistoryRef.current.timestamps.push(timestamp);

    // Filter by time range
    const filterByTime = (data) => data.filter(d => d.x >= cutoff);

    dataHistoryRef.current.activeUsers = filterByTime(dataHistoryRef.current.activeUsers);
    dataHistoryRef.current.eventsPerSecond = filterByTime(dataHistoryRef.current.eventsPerSecond);
    dataHistoryRef.current.errorRate = filterByTime(dataHistoryRef.current.errorRate);
    dataHistoryRef.current.timestamps = dataHistoryRef.current.timestamps.slice(-timeRange);

    // Update chart data
    const labels = dataHistoryRef.current.timestamps;
    
    setChartData({
      activeUsers: {
        labels,
        datasets: [
          {
            label: 'Active Users',
            data: dataHistoryRef.current.activeUsers.map(d => d.y),
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            fill: true,
            tension: 0.4,
          },
        ],
      },
      eventsPerSecond: {
        labels,
        datasets: [
          {
            label: 'Events/sec',
            data: dataHistoryRef.current.eventsPerSecond.map(d => d.y),
            borderColor: 'rgb(54, 162, 235)',
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            fill: true,
            tension: 0.4,
          },
        ],
      },
      errorRate: {
        labels,
        datasets: [
          {
            label: 'Error Rate (%)',
            data: dataHistoryRef.current.errorRate.map(d => d.y),
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            fill: true,
            tension: 0.4,
          },
        ],
      },
      topRoutes: {
        labels: agg60s.topRoutes.map(r => r.route),
        datasets: [
          {
            label: 'Events',
            data: agg60s.topRoutes.map(r => r.count),
            backgroundColor: [
              'rgba(255, 99, 132, 0.6)',
              'rgba(54, 162, 235, 0.6)',
              'rgba(255, 206, 86, 0.6)',
              'rgba(75, 192, 192, 0.6)',
              'rgba(153, 102, 255, 0.6)',
            ],
          },
        ],
      },
    });
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'top',
      },
      tooltip: {
        mode: 'index',
        intersect: false,
      },
      zoom: {
        zoom: {
          wheel: {
            enabled: true,
          },
          pinch: {
            enabled: true,
          },
          mode: 'x',
        },
        pan: {
          enabled: true,
          mode: 'x',
        },
      },
    },
    scales: {
      x: {
        display: true,
        title: {
          display: true,
          text: 'Time',
        },
      },
      y: {
        display: true,
        beginAtZero: true,
      },
    },
  };

  const barOptions = {
    ...chartOptions,
    scales: {
      ...chartOptions.scales,
      y: {
        beginAtZero: true,
      },
    },
  };

  const currentAgg = aggregates.find(a => a.window === 60000) || {};

  if (error && connectionStatus === 'error') {
    return (
      <div className="dashboard-error">
        <h2>Connection Error</h2>
        <p>{error}</p>
        <button onClick={() => websocketService.connect()}>Reconnect</button>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Real-Time Analytics Dashboard</h1>
        <div className="dashboard-controls">
          <div className={`status-indicator ${connectionStatus}`}>
            {connectionStatus === 'connected' ? '🟢 Connected' : '🔴 Disconnected'}
          </div>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(parseInt(e.target.value, 10))}
            className="time-range-select"
          >
            <option value={30}>Last 30 seconds</option>
            <option value={60}>Last 60 seconds</option>
            <option value={300}>Last 5 minutes</option>
            <option value={600}>Last 10 minutes</option>
          </select>
        </div>
      </div>

      <div className="dashboard-stats">
        <div className="stat-card">
          <h3>Active Users</h3>
          <p className="stat-value">{currentAgg.uniqueUsers || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Events/sec</h3>
          <p className="stat-value">{currentAgg.eventsPerSecond?.toFixed(2) || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Total Events</h3>
          <p className="stat-value">{currentAgg.count || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Error Rate</h3>
          <p className="stat-value">{(currentAgg.errorRate * 100 || 0).toFixed(2)}%</p>
        </div>
      </div>

      <div className="dashboard-charts">
        <div className="chart-container">
          <h2>Active Users</h2>
          <div className="chart-wrapper">
            <Line data={chartData.activeUsers} options={chartOptions} />
          </div>
        </div>

        <div className="chart-container">
          <h2>Events per Second</h2>
          <div className="chart-wrapper">
            <Line data={chartData.eventsPerSecond} options={chartOptions} />
          </div>
        </div>

        <div className="chart-container">
          <h2>Error Rate</h2>
          <div className="chart-wrapper">
            <Line data={chartData.errorRate} options={chartOptions} />
          </div>
        </div>

        <div className="chart-container">
          <h2>Top Routes</h2>
          <div className="chart-wrapper">
            <Bar data={chartData.topRoutes} options={barOptions} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

