# Setup Guide for Local System

This guide will help you set up and run the Real-Time Analytics Dashboard on your local Windows system.

## Prerequisites Installation

### 1. Install Node.js (Required)

Node.js includes npm (Node Package Manager).

**Option A: Download from Official Website**
1. Go to https://nodejs.org/
2. Download the LTS version (recommended: v18 or v20)
3. Run the installer
4. Follow the installation wizard
5. Restart your terminal/PowerShell after installation

**Option B: Using Chocolatey (if you have it)**
```powershell
choco install nodejs-lts
```

**Verify Installation:**
```powershell
node --version
npm --version
```

You should see version numbers like `v18.x.x` and `9.x.x`

### 2. Install Docker Desktop (Required for MongoDB)

**Option A: Download Docker Desktop**
1. Go to https://www.docker.com/products/docker-desktop/
2. Download Docker Desktop for Windows
3. Install and restart your computer
4. Launch Docker Desktop and wait for it to start

**Option B: Using Chocolatey**
```powershell
choco install docker-desktop
```

**Verify Installation:**
```powershell
docker --version
docker-compose --version
```

## Project Setup Steps

Once prerequisites are installed, follow these steps:

### Step 1: Create Environment File

Create a file named `.env` in the `backend` folder:

**File: `backend/.env`**
```
NODE_ENV=development
PORT=3001
MONGODB_URI=mongodb://admin:admin123@localhost:27017/analytics?authSource=admin
JWT_SECRET=your-super-secret-jwt-key-change-in-production
JWT_EXPIRES_IN=24h
CORS_ORIGIN=http://localhost:3000
WS_MAX_MESSAGE_SIZE=100000
WS_RATE_LIMIT_WINDOW=60000
WS_RATE_LIMIT_MAX=1000
REST_RATE_LIMIT_WINDOW=60000
REST_RATE_LIMIT_MAX=100
LOG_LEVEL=info
```

**PowerShell Command:**
```powershell
New-Item -Path "backend\.env" -ItemType File -Force
# Then copy the content above into the file, or use:
@"
NODE_ENV=development
PORT=3001
MONGODB_URI=mongodb://admin:admin123@localhost:27017/analytics?authSource=admin
JWT_SECRET=your-super-secret-jwt-key-change-in-production
JWT_EXPIRES_IN=24h
CORS_ORIGIN=http://localhost:3000
WS_MAX_MESSAGE_SIZE=100000
WS_RATE_LIMIT_WINDOW=60000
WS_RATE_LIMIT_MAX=1000
REST_RATE_LIMIT_WINDOW=60000
REST_RATE_LIMIT_MAX=100
LOG_LEVEL=info
"@ | Out-File -FilePath "backend\.env" -Encoding utf8
```

### Step 2: Install Dependencies

```powershell
# Install root dependencies
npm install

# Install backend dependencies
cd backend
npm install
cd ..

# Install frontend dependencies
cd frontend
npm install
cd ..
```

Or use the convenience script:
```powershell
npm run install:all
```

### Step 3: Start MongoDB

**Using Docker (Recommended):**
```powershell
docker-compose up -d
```

Wait a few seconds for MongoDB to start. Verify it's running:
```powershell
docker ps
```

**Alternative: Install MongoDB Locally**
If you don't want to use Docker, install MongoDB Community Edition:
1. Download from https://www.mongodb.com/try/download/community
2. Install MongoDB
3. Start MongoDB service
4. Update `MONGODB_URI` in `backend/.env` to: `mongodb://localhost:27017/analytics`

### Step 4: Seed Database (Optional)

Populate the database with sample data:
```powershell
npm run seed
```

### Step 5: Start Development Servers

**Option A: Run Both Servers (Recommended)**
```powershell
npm run dev
```

This starts both backend (port 3001) and frontend (port 3000) concurrently.

**Option B: Run Separately**

Terminal 1 - Backend:
```powershell
cd backend
npm run dev
```

Terminal 2 - Frontend:
```powershell
cd frontend
npm start
```

### Step 6: Access the Dashboard

Open your web browser and navigate to:
```
http://localhost:3000
```

## Troubleshooting

### "Node/npm not found"
- Make sure Node.js is installed and added to PATH
- Restart your terminal/PowerShell
- Verify with: `node --version`

### "Docker not found"
- Install Docker Desktop
- Make sure Docker Desktop is running
- Restart your terminal

### "Port already in use"
- Change the port in `backend/.env` (PORT=3001)
- Or stop the application using that port

### "Cannot connect to MongoDB"
- Make sure MongoDB is running: `docker ps`
- Check MongoDB logs: `docker-compose logs mongodb`
- Verify connection string in `backend/.env`

### "Module not found" errors
- Run `npm install` in both backend and frontend directories
- Delete `node_modules` and reinstall if needed

### MongoDB Connection String Issues
If using Docker, the connection string should be:
```
mongodb://admin:admin123@localhost:27017/analytics?authSource=admin
```

If using local MongoDB (no Docker):
```
mongodb://localhost:27017/analytics
```

## Quick Commands Reference

```powershell
# Install all dependencies
npm run install:all

# Start MongoDB
docker-compose up -d

# Stop MongoDB
docker-compose down

# Seed database
npm run seed

# Start development servers
npm run dev

# Run load test
cd backend
npm run test:load
```

## Next Steps

Once everything is running:
1. Open http://localhost:3000 in your browser
2. Use the Event Generator to create test events
3. Watch the dashboard update in real-time
4. Try the load generator for stress testing

For more details, see `README.md` and `QUICKSTART.md`.

