# 🚀 START HERE - Quick Setup Instructions

## ⚠️ Prerequisites Required

Before running this project, you need to install:

### 1. Node.js (Required)
- Download from: https://nodejs.org/
- Install the LTS version (v18 or v20)
- Restart your terminal after installation
- Verify: `node --version` should show a version number

### 2. Docker Desktop (Required for MongoDB)
- Download from: https://www.docker.com/products/docker-desktop/
- Install and restart your computer
- Launch Docker Desktop and wait for it to start
- Verify: `docker --version` should show a version number

## 🎯 Quick Start (After Prerequisites)

### Option 1: Automated Setup (Recommended)

Run the PowerShell setup script:
```powershell
.\setup.ps1
```

Then start the servers:
```powershell
npm run dev
```

### Option 2: Manual Setup

1. **Create environment file:**
   - File exists at: `backend\.env`
   - If missing, copy content from `SETUP_GUIDE.md`

2. **Install dependencies:**
   ```powershell
   npm run install:all
   ```

3. **Start MongoDB:**
   ```powershell
   docker-compose up -d
   ```

4. **Start development servers:**
   ```powershell
   npm run dev
   ```

5. **Open in browser:**
   - Go to: http://localhost:3000

## 📚 Detailed Instructions

For complete setup instructions, troubleshooting, and more details, see:
- **SETUP_GUIDE.md** - Complete setup guide with troubleshooting
- **QUICKSTART.md** - Quick reference guide
- **README.md** - Full project documentation

## ✅ Verify Installation

Run these commands to verify everything is installed:

```powershell
node --version      # Should show v18.x.x or higher
npm --version       # Should show 9.x.x or higher
docker --version    # Should show Docker version
```

## 🆘 Need Help?

If you encounter issues:
1. Check **SETUP_GUIDE.md** for troubleshooting
2. Make sure all prerequisites are installed
3. Verify Docker Desktop is running
4. Check that ports 3000 and 3001 are not in use

